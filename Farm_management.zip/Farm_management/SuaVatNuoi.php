<?php
require 'db_connect.php';

$ma = $_GET['ma'] ?? '';

// Lấy dữ liệu hiện tại
$stmt = mysqli_prepare($conn, "SELECT * FROM VATNUOI WHERE MaVatNuoi = ?");
mysqli_stmt_bind_param($stmt, "s", $ma);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$row) {
    header("Location: index.php");
    exit;
}

// Xử lý khi submit
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ten       = trim($_POST['TenVatNuoi'] ?? '');
    $giong     = trim($_POST['Giong'] ?? '');
    $ngaySinh  = $_POST['NgaySinh'] ?? '';
    $gioiTinh  = $_POST['GioiTinh'] ?? '';
    $canNang   = $_POST['CanNang'] ?? '';
    $tinhTrang = trim($_POST['TinhTrang'] ?? '');
    $maChuong  = trim($_POST['MaChuong'] ?? '');

    if (!$ten || !$giong || !$ngaySinh || !$tinhTrang || !$maChuong) {
        header("Location: suaVatNuoi.php?ma=$ma&msg=thieu_thong_tin");
        exit;
    }

    $stmt = mysqli_prepare($conn,
        "UPDATE VATNUOI
         SET TenVatNuoi = ?, Giong = ?, NgaySinh = ?,
             GioiTinh = ?, CanNang = ?, TinhTrang = ?, MaChuong = ?
         WHERE MaVatNuoi = ?"
    );
    mysqli_stmt_bind_param($stmt, "ssssssi", $ten, $giong, $ngaySinh, $gioiTinh, $canNang, $tinhTrang, $maChuong, $ma);
    $success = mysqli_stmt_execute($stmt);

    if (!$success) {
        die("Lỗi cập nhật: " . mysqli_error($conn));
    }

    header("Location: index.php");
    mysqli_stmt_close($stmt);
    exit;
}

$dsChuong = mysqli_query($conn, "SELECT MaChuong, TenChuong FROM ChuongTrai");
if ($dsChuong === false) {
    die("Lỗi truy vấn chuồng: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Sửa vật nuôi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>
<body>
<div class="container mt-4" style="max-width:500px">
    <h4> Sửa vật nuôi: <b><?= htmlspecialchars($row['MaVatNuoi']) ?></b></h4>

    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'thieu_thong_tin'): ?>
        <div class="alert alert-warning">Vui lòng điền đầy đủ thông tin!</div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label>Tên vật nuôi</label>
            <input type="text" name="TenVatNuoi" class="form-control"
                   value="<?= htmlspecialchars($row['TenVatNuoi']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Giống loài</label>
            <input type="text" name="Giong" class="form-control"
                   value="<?= htmlspecialchars($row['Giong']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Ngày sinh</label>
            <input type="date" name="NgaySinh" class="form-control"
                   value="<?= htmlspecialchars($row['NgaySinh']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Giới tính</label>
            <select name="GioiTinh" class="form-select">
                <?php foreach (['Đực', 'Cái'] as $gt): ?>
                    <option value="<?= $gt ?>" <?= $row['GioiTinh'] === $gt ? 'selected' : '' ?>>
                        <?= $gt ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Cân nặng (Kg)</label>
            <input type="number" name="CanNang" class="form-control"
                   value="<?= htmlspecialchars($row['CanNang']) ?>" min="0" step="0.1">
        </div>
        <div class="mb-3">
            <label>Tình trạng</label>
            <select name="TinhTrang" class="form-select">
                <?php foreach (['Khỏe mạnh', 'Bệnh', 'Đã bán'] as $tt): ?>
                    <option value="<?= $tt ?>" <?= $row['TinhTrang'] === $tt ? 'selected' : '' ?>>
                        <?= $tt ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Chuồng</label>
            <select name="MaChuong" class="form-select">
                <?php while ($c = mysqli_fetch_assoc($dsChuong)): ?>
                    <option value="<?= htmlspecialchars($c['MaChuong']) ?>"
                        <?= $row['MaChuong'] === $c['MaChuong'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c['TenChuong']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-warning"> Cập nhật</button>
        <a href="index.html">← Quay lại</a>
    </form>
</div>
</body>
</html>
