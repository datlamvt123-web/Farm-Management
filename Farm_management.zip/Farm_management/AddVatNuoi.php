<?php
require 'db_connect.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    $ma        = trim($_POST['MaVatNuoi'] ?? '');
    $ten       = trim($_POST['TenVatNuoi'] ?? '');
    $giong     = trim($_POST['Giong'] ?? '');
    $ngaySinh  = trim($_POST['NgaySinh'] ?? '');
    $gioiTinh  = trim($_POST['GioiTinh'] ?? '');
    $canNang   = trim($_POST['CanNang'] ?? '');
    $tinhTrang = trim($_POST['TinhTrang'] ?? '');
    $maChuong  = trim($_POST['MaChuong'] ?? '');

    // Thay đổi tên file giao diện nếu không phải index.php
    $redirectUrl = 'index.php';

    if ($ma === '' || $ten === '' || $giong === '' || $ngaySinh === '' || $gioiTinh === '' || $tinhTrang === '' || $maChuong === '') {
        header("Location: $redirectUrl");
        exit;
    }

    // Kiểm tra mã đã tồn tại chưa
    $checkSql = "SELECT MaVatNuoi FROM VATNUOI WHERE MaVatNuoi = ?";
    $check = mysqli_prepare($conn, $checkSql);
    mysqli_stmt_bind_param($check, "s", $ma);
    mysqli_stmt_execute($check);
    $checkResult = mysqli_stmt_get_result($check);

    if ($checkResult === false) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }

    if (mysqli_fetch_assoc($checkResult) !== false) {
        header("Location: $redirectUrl");
        mysqli_stmt_close($check);
        exit;
    }
    mysqli_stmt_close($check);

    // Kiểm tra MaChuong tồn tại
    $checkChuongSql = "SELECT MaChuong FROM ChuongTrai WHERE MaChuong = ?";
    $checkChuong = mysqli_prepare($conn, $checkChuongSql);
    mysqli_stmt_bind_param($checkChuong, "i", $maChuong);
    mysqli_stmt_execute($checkChuong);
    $checkChuongResult = mysqli_stmt_get_result($checkChuong);

    if ($checkChuongResult === false) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }

    if (mysqli_fetch_assoc($checkChuongResult) === null) {
        mysqli_stmt_close($checkChuong);
        header("Location: $redirectUrl");
        exit;
    }
    mysqli_stmt_close($checkChuong);

    // Thêm mới
    $insertSql = "INSERT INTO VATNUOI
        (MaVatNuoi, TenVatNuoi, Giong, NgaySinh, GioiTinh, CanNang, TinhTrang, MaChuong)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $insertSql);
    mysqli_stmt_bind_param($stmt, "sssssssi", $ma, $ten, $giong, $ngaySinh, $gioiTinh, $canNang, $tinhTrang, $maChuong);
    $success = mysqli_stmt_execute($stmt);

    if (!$success) {
        die("Lỗi thêm mới: " . mysqli_error($conn));
    }

    mysqli_stmt_close($stmt);

    header("Location: $redirectUrl");
    exit;
}
?>