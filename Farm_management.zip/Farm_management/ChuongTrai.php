<?php
require 'db_connect.php';

// Test: Get coops data
$chuong = [];
$chuongRows = mysqli_query($conn, "SELECT MaChuong, TenChuong, SucChua, SoLuongHienTai FROM ChuongTrai ORDER BY MaChuong");
if ($chuongRows !== false) {
    while ($item = mysqli_fetch_assoc($chuongRows)) {
        $chuong[] = $item;
    }
    mysqli_free_result($chuongRows);
}

echo "<h1>Test Chuong Data</h1>";
echo "<pre>";
echo "Coops count: " . count($chuong) . "\n";
if (count($chuong) > 0) {
    print_r($chuong);
} else {
    echo "No coops found!";
}
echo "</pre>";
?>
