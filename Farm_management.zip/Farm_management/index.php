<?php
require 'db_connect.php';

$vatNuoi = [];
$lichSu = [];

$rows = mysqli_query($conn, "SELECT MaVatNuoi, TenVatNuoi, Giong, NgaySinh, GioiTinh, CanNang, TinhTrang, MaChuong FROM VATNUOI ORDER BY MaVatNuoi");
if ($rows !== false) {
    while ($item = mysqli_fetch_assoc($rows)) {
        $vatNuoi[] = $item;
    }
    mysqli_free_result($rows);
}

$historyRows = mysqli_query($conn, "SELECT MaVatNuoi, TenBenh, DieuTri FROM SUCKHOE ORDER BY MaVatNuoi");
if ($historyRows !== false) {
    while ($item = mysqli_fetch_assoc($historyRows)) {
        $lichSu[] = $item;
    }
    mysqli_free_result($historyRows);
}

$chuong = [];
$chuongRows = mysqli_query($conn, "SELECT MaChuong, TenChuong, SucChua, SoLuongHienTai FROM ChuongTrai ORDER BY MaChuong");
if ($chuongRows !== false) {
    while ($item = mysqli_fetch_assoc($chuongRows)) {
        $chuong[] = $item;
    }
    mysqli_free_result($chuongRows);
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Trang Trại</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .is-healthy td { background-color: #d1e7dd !important; color: #0f5132 !important; }
        .is-sick td { background-color: #f8d7da !important; color: #842029 !important; }
        .is-warning td { background-color: #fff3cd !important; color: #664d03 !important; }
        body { background-color: #f4f7f6; padding-top: 20px; font-family: sans-serif; }
        .main-card { border: none; box-shadow: 0 0 20px rgba(0,0,0,0.1); border-radius: 15px; }
        .nav-tabs .nav-link { color: #495057; font-weight: 600; border: none; }
        .nav-tabs .nav-link.active { color: #198754; border-bottom: 3px solid #198754; background: none; }
        .table { border-spacing: 0 5px; border-collapse: separate; }
    </style>
</head>
<body>
<div class="container">
    <div class="card main-card p-4">
        <h3 class="text-success fw-bold text-center mb-4">HỆ THỐNG QUẢN LÝ TỔNG HỢP</h3>
        <div class="row g-2 mb-4">
            <div class="col-md-5">
                <input type="text" id="mainSearch" class="form-control" placeholder="🔍 Tìm mã vật nuôi...">
            </div>
            <div class="col-md-4">
                <select id="mainFilter" class="form-select">
                    <option value="">🎯 Tất cả trạng thái (Filter)</option>
                    <option value="Đang Nuôi">✅ Đang Nuôi</option>
                    <option value="Bệnh">❌ Đang Bệnh</option>
                    <option value="Mang Thai">🤰 Mang Thai</option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-success w-100 fw-bold" onclick="openAddModal()">+ THÊM DỮ LIỆU</button>
            </div>
        </div>
        <ul class="nav nav-tabs mb-3" id="farmTabs">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab1">1. Danh sách vật nuôi</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab2">2. Tình trạng sức khỏe</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab3">3. Lịch sử bệnh</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab4">4. Quản lý chuồng</button></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="tab1">
                <div class="table-responsive">
                    <table class="table align-middle" id="tableVatNuoi">
                        <thead class="table-dark">
                            <tr><th>Mã số</th><th>Tên</th><th>Giống</th><th>Ngày sinh</th><th>Giới tính</th><th>Cân nặng</th><th>Trạng thái</th><th>Chuồng</th><th>Thao tác</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vatNuoi as $item):
                                $color = $item['TinhTrang'] === 'Bệnh' ? 'is-sick' : ($item['TinhTrang'] === 'Mang Thai' ? 'is-warning' : 'is-healthy');
                            ?>
                            <tr class="<?= $color ?>" data-status="<?= htmlspecialchars($item['TinhTrang']) ?>">
                                <td><?= htmlspecialchars($item['MaVatNuoi']) ?></td>
                                <td><?= htmlspecialchars($item['TenVatNuoi']) ?></td>
                                <td><?= htmlspecialchars($item['Giong']) ?></td>
                                <td><?= htmlspecialchars($item['NgaySinh']) ?></td>
                                <td><?= htmlspecialchars($item['GioiTinh']) ?></td>
                                <td><?= htmlspecialchars($item['CanNang']) ?></td>
                                <td><?= htmlspecialchars($item['TinhTrang']) ?></td>
                                <td><?= htmlspecialchars($item['MaChuong']) ?></td>
                                <td>
                                    <a href="SuaVatNuoi.php?ma=<?= urlencode($item['MaVatNuoi']) ?>" class="btn btn-sm btn-dark">Sửa</a>
                                    <a href="XoaVatNuoi.php?ma=<?= urlencode($item['MaVatNuoi']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Xóa vật nuôi <?= htmlspecialchars($item['MaVatNuoi']) ?>?')">Xóa</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="tab2">
                <div class="table-responsive">
                    <table class="table align-middle" id="tableSucKhoe">
                        <thead class="table-primary">
                            <tr><th>Mã số</th><th>Tình trạng</th><th>Kết quả</th><th>Thao tác</th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vatNuoi as $item):
                                $color = $item['TinhTrang'] === 'Bệnh' ? 'is-sick' : ($item['TinhTrang'] === 'Mang Thai' ? 'is-warning' : 'is-healthy');
                                $result = $item['TinhTrang'] === 'Bệnh' ? 'Cần xử lý' : 'Ổn định';
                            ?>
                            <tr class="<?= $color ?>" data-status="<?= htmlspecialchars($item['TinhTrang']) ?>">
                                <td><?= htmlspecialchars($item['MaVatNuoi']) ?></td>
                                <td><?= htmlspecialchars($item['TinhTrang']) ?></td>
                                <td><?= htmlspecialchars($result) ?></td>
                                <td><a href="XoaVatNuoi.php?ma=<?= urlencode($item['MaVatNuoi']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Xóa vật nuôi <?= htmlspecialchars($item['MaVatNuoi']) ?>?')">Xóa</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="tab3">
                <div class="table-responsive">
                    <table class="table align-middle" id="tableLichSu">
                        <thead class="table-danger">
                            <tr><th>Mã số</th><th>Tên bệnh</th><th>Điều trị</th><th>Thao tác</th></tr>
                        </thead>
                        <tbody>
                            <?php if (count($lichSu) === 0): ?>
                                <tr><td colspan="4" class="text-center">Chưa có lịch sử bệnh</td></tr>
                            <?php else: ?>
                                <?php foreach ($lichSu as $item): ?>
                                    <tr class="is-sick" data-status="Bệnh">
                                        <td><?= htmlspecialchars($item['MaVatNuoi']) ?></td>
                                        <td><?= htmlspecialchars($item['TenBenh']) ?></td>
                                        <td><?= htmlspecialchars($item['DieuTri']) ?></td>
                                        <td><a href="XoaVatNuoi.php?ma=<?= urlencode($item['MaVatNuoi']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Xóa vật nuôi <?= htmlspecialchars($item['MaVatNuoi']) ?>?')">Xóa</a></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="tab4">
                <div class="table-responsive">
                    <table class="table align-middle" id="tableChuong">
                        <thead class="table-info">
                            <tr><th>Mã chuồng</th><th>Tên chuồng</th><th>Sức chứa</th><th>Số lượng hiện tại/tối đa</th><th>Tình trạng</th></tr>
                        </thead>
                        <tbody>
                            <?php if (count($chuong) === 0): ?>
                                <tr><td colspan="5" class="text-center">Chưa có chuồng trại</td></tr>
                            <?php else: ?>
                                <?php foreach ($chuong as $item): 
                                    $used = intval($item['SoLuongHienTai']);
                                    $capacity = intval($item['SucChua']);
                                    $percent = $capacity > 0 ? round(($used / $capacity) * 100) : 0;
                                    $statusColor = $percent >= 90 ? 'danger' : ($percent >= 70 ? 'warning' : 'success');
                                ?>
                                <tr class="table-<?= $statusColor ?>">
                                    <td><strong><?= htmlspecialchars($item['MaChuong']) ?></strong></td>
                                    <td><?= htmlspecialchars($item['TenChuong']) ?></td>
                                    <td><?= htmlspecialchars($item['SucChua']) ?></td>
                                    <td>
                                        <div class="progress" style="height: 25px;">
                                            <div class="progress-bar bg-<?= $statusColor ?>" role="progressbar" style="width: <?= $percent ?>%">
                                                <?= htmlspecialchars($item['SoLuongHienTai']) ?> / <?= htmlspecialchars($item['SucChua']) ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if ($percent >= 90): ?>
                                            <span class="badge bg-danger">🔴 Đầy</span>
                                        <?php elseif ($percent >= 70): ?>
                                            <span class="badge bg-warning">🟡 Gần đầy</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">🟢 Còn trống</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="farmModal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content shadow" id="farmForm" action="AddVatNuoi.php" method="post">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title">Thêm vật nuôi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3"><label class="fw-bold">Mã vật nuôi</label><input type="text" id="fId" name="MaVatNuoi" class="form-control" required></div>
                <div class="mb-3"><label class="fw-bold">Tên vật nuôi</label><input type="text" id="fLoai" name="TenVatNuoi" class="form-control" required></div>
                <div class="mb-3"><label class="fw-bold">Giống</label><input type="text" id="fGiong" name="Giong" class="form-control" required></div>
                <div class="mb-3"><label class="fw-bold">Ngày sinh</label><input type="date" id="fNgaySinh" name="NgaySinh" class="form-control" required></div>
                <div class="mb-3">
                    <label class="fw-bold">Giới tính</label>
                    <select id="fGioiTinh" name="GioiTinh" class="form-select" required>
                        <option value="">Chọn giới tính</option>
                        <option value="M">Nam</option>
                        <option value="F">Nữ</option>
                    </select>
                </div>
                <div class="mb-3"><label class="fw-bold">Cân nặng (kg)</label><input type="number" step="0.1" id="fCanNang" name="CanNang" class="form-control" required></div>
                <div class="mb-3">
                    <label class="fw-bold">Trạng thái</label>
                    <select id="fStatus" name="TinhTrang" class="form-select" required>
                        <option value="Đang Nuôi">Đang Nuôi</option>
                        <option value="Bệnh">Bệnh</option>
                        <option value="Mang Thai">Mang Thai</option>
                    </select>
                </div>
                <div id="sickDetail" style="display:none;" class="p-2 border rounded bg-light">
                    <div class="mb-2"><label class="small fw-bold">Tên bệnh</label><input type="text" id="fBenh" class="form-control form-control-sm"></div>
                    <div class="mb-2"><label class="small fw-bold">Cách điều trị</label><input type="text" id="fDieuTri" class="form-control form-control-sm"></div>
                </div>
                <div class="mb-3">
                    <label class="fw-bold">Mã chuồng</label>
                    <select id="fMaChuong" name="MaChuong" class="form-select" required>
                        <option value="">Chọn chuồng</option>
                        <?php
                        mysqli_data_seek($chuongRows, 0);
                        while ($chuong = mysqli_fetch_assoc($chuongRows)):
                        ?>
                            <option value="<?= htmlspecialchars($chuong['MaChuong']) ?>"><?= htmlspecialchars($chuong['TenChuong']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success w-100">LƯU DỮ LIỆU</button>
            </div>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const farmModal = new bootstrap.Modal(document.getElementById('farmModal'));

    function openAddModal() {
        document.getElementById('farmForm').reset();
        document.getElementById('sickDetail').style.display = 'none';
        farmModal.show();
    }

    document.getElementById('fStatus').addEventListener('change', function() {
        document.getElementById('sickDetail').style.display = (this.value === 'Bệnh') ? 'block' : 'none';
    });

    function applyFilters() {
        const sText = document.getElementById('mainSearch').value.toLowerCase();
        const fStatus = document.getElementById('mainFilter').value;
        document.querySelectorAll('tbody tr').forEach(row => {
            const rowText = row.innerText.toLowerCase();
            const rowStatus = row.getAttribute('data-status');
            const matchSearch = rowText.includes(sText);
            const matchFilter = (fStatus === "" || rowStatus === fStatus);
            row.style.display = (matchSearch && matchFilter) ? '' : 'none';
        });
    }

    document.getElementById('mainSearch').addEventListener('input', applyFilters);
    document.getElementById('mainFilter').addEventListener('change', applyFilters);
</script>
</body>
</html>
