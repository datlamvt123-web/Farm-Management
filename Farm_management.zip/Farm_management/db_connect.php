<?php
$conn = mysqli_connect("localhost", "root", "", "Farm_management");

if ($conn === false) {
    die("Kết nối thất bại: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");
?>