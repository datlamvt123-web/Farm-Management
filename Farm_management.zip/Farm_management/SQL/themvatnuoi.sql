-- BÒ
INSERT INTO VATNUOI VALUES 
('B001', N'Bò 1', N'Bò vàng', '2023-01-10', 'M', 250, N'BinhThuong', 1),
('B002', N'Bò 2', N'Bò sữa', '2022-05-15', 'F', 300, N'Benh', 9),
('B003', N'Bò 3', N'Bò lai', '2022-08-20', 'F', 280, N'CoThai', 6);

-- HEO
INSERT INTO VATNUOI VALUES 
('H001', N'Heo 1', N'Heo rừng', '2023-02-12', 'M', 80, N'BinhThuong', 3),
('H002', N'Heo 2', N'Heo siêu nạc', '2022-06-18', 'F', 90, N'Benh', 10),
('H003', N'Heo 3', N'Heo lai', '2022-09-25', 'F', 85, N'CoThai', 7);

-- DÊ
INSERT INTO VATNUOI VALUES 
('D001', N'Dê 1', N'Dê núi', '2023-03-05', 'M', 40, N'BinhThuong', 5),
('D002', N'Dê 2', N'Dê sữa', '2022-07-10', 'F', 45, N'Benh', 11),
('D003', N'Dê 3', N'Dê lai', '2022-10-30', 'F', 42, N'CoThai', 8);