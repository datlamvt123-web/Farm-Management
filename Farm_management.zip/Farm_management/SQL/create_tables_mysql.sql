-- table Vật Nuôi --
CREATE TABLE IF NOT EXISTS VATNUOI (
    MaVatNuoi VARCHAR(10) PRIMARY KEY,
    TenVatNuoi VARCHAR(50) NOT NULL,
    Giong VARCHAR(50),
    NgaySinh DATE,
    GioiTinh CHAR(1),
    CanNang DECIMAL(6,2),
    TinhTrang VARCHAR(20) DEFAULT 'Đang Nuôi',
    MaChuong INT
);

-- Table Sức khỏe --
CREATE TABLE IF NOT EXISTS SUCKHOE (
    MaSucKhoe INT AUTO_INCREMENT PRIMARY KEY,
    MaVatNuoi VARCHAR(10) NOT NULL,
    NgayKiemTra DATE NOT NULL,
    TinhTrang VARCHAR(50) NOT NULL,
    TenBenh VARCHAR(100),
    TrieuChung TEXT,
    DieuTri TEXT,
    KetQua VARCHAR(50),

    FOREIGN KEY (MaVatNuoi)
    REFERENCES VATNUOI(MaVatNuoi)
    ON DELETE CASCADE
);

-- Table Chuồng trại --
CREATE TABLE IF NOT EXISTS ChuongTrai (
    MaChuong INT PRIMARY KEY,
    TenChuong VARCHAR(100),
    SucChua INT,
    SoLuongHienTai INT
);

-- Table Vệ sinh chuồng --
CREATE TABLE IF NOT EXISTS VeSinhChuong (
    MaVS INT PRIMARY KEY,
    MaChuong INT,
    NgayVeSinh DATE,
    TrangThai VARCHAR(50),
    FOREIGN KEY (MaChuong) REFERENCES ChuongTrai(MaChuong)
);

-- Table Nhân Viên --
CREATE TABLE IF NOT EXISTS NhanVien (
    MaNhanVien VARCHAR(50) PRIMARY KEY,
    HoTen VARCHAR(200),
    ChucVu VARCHAR(50), -- Nhân viên/Quản lý
    SoDienThoai VARCHAR(20),
    Email VARCHAR(100),
    NgayVaoLam DATE
);

-- Table Tài Khoản --
CREATE TABLE IF NOT EXISTS TaiKhoan (
    MaTaiKhoan VARCHAR(50) PRIMARY KEY,
    TenDangNhap VARCHAR(100) NOT NULL,
    MatKhau VARCHAR(255) NOT NULL,
    VaiTro VARCHAR(50), -- Chủ trại/Quản lý/Nhân viên
    MaNhanVien VARCHAR(50),
    TrangThai VARCHAR(50), -- Hoạt động/Khóa
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVien(MaNhanVien)
);

-- Table Phân Công (Lịch làm việc) --
CREATE TABLE IF NOT EXISTS PhanCong (
    MaPhanCong VARCHAR(50) PRIMARY KEY,
    MaNhanVien VARCHAR(50),
    NgayLam DATE,
    CaLam VARCHAR(50), -- Sáng/Chiều/Tối
    MoTaCongViec TEXT,
    KetQuaThucHien TEXT,
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVien(MaNhanVien)
);

-- 4. Table Chi Phí --
CREATE TABLE IF NOT EXISTS ChiPhi (
    MaChiPhi VARCHAR(50) PRIMARY KEY,
    LoaiChiPhi VARCHAR(100), -- Thức ăn/Thuốc/Nhân công...
    SoTien DECIMAL(18, 2),
    NgayPhatSinh DATE,
    GhiChu TEXT,
    MaNhanVien VARCHAR(50), -- Người nhập chi phí
    FOREIGN KEY (MaNhanVien) REFERENCES NhanVien(MaNhanVien)
);

-- table thức ăn --
CREATE TABLE IF NOT EXISTS ThucAn (
    MaThucAn VARCHAR(10) PRIMARY KEY,
    TenThucAn VARCHAR(100),
    LoaiThucAn VARCHAR(50),
    DonVi VARCHAR(20),
    SoLuongTonKho DECIMAL(10,2)
);

-- table lịch cho ăn --
CREATE TABLE IF NOT EXISTS LichChoAn (
    MaLichChoAn VARCHAR(10) PRIMARY KEY,
    GioChoAn TIME,
    LuongThucAn DECIMAL(10,2),
    TanSuat VARCHAR(50),
    MaVatNuoi VARCHAR(10),
    MaThucAn VARCHAR(10),

    FOREIGN KEY (MaVatNuoi) REFERENCES VATNUOI(MaVatNuoi),
    FOREIGN KEY (MaThucAn) REFERENCES ThucAn(MaThucAn)
);

-- Thêm foreign key cho MaChuong trong VATNUOI
ALTER TABLE VATNUOI
ADD CONSTRAINT FK_VatNuoi_Chuong
FOREIGN KEY (MaChuong) REFERENCES ChuongTrai(MaChuong);

-- Table trung gian PhanCong_LichChoAn
CREATE TABLE IF NOT EXISTS PhanCong_LichChoAn (
    MaPhanCong VARCHAR(50),
    MaLichChoAn VARCHAR(10),
    PRIMARY KEY (MaPhanCong, MaLichChoAn),
    FOREIGN KEY (MaPhanCong) REFERENCES PhanCong(MaPhanCong),
    FOREIGN KEY (MaLichChoAn) REFERENCES LichChoAn(MaLichChoAn)
);