INSERT INTO ChuongTrai (MaChuong, TenChuong, SucChua, SoLuongHienTai) VALUES
(1, 'CB1 - Chuồng Bò', 20, 0),
(2, 'CG1 - Chuồng Gà', 100, 0),
(3, 'CH1 - Chuồng Heo', 15, 0),
(4, 'CV1 - Chuồng Vịt', 80, 0),
(5, 'CD1 - Chuồng Dê', 25, 0),
(6, 'CSSBo - Chuồng Sinh Sản Bò', 10, 0),
(7, 'CSSHeo - Chuồng Sinh Sản Heo', 8, 0),
(8, 'CSSDe - Chuồng Sinh Sản Dê', 10, 0),
(9, 'CCBBo - Chuồng Chăm Bệnh Bò', 10, 0),
(10, 'CCBeo - Chuồng Chăm Bệnh Heo', 8, 0),
(11, 'CCBe - Chuồng Chăm Bệnh Dê', 10, 0);