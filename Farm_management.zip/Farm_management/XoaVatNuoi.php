<?php
require 'db_connect.php';

$ma = $_GET['ma'] ?? '';

// Kiểm tra còn hồ sơ sức khỏe liên kết không
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS so FROM SUCKHOE WHERE MaVatNuoi = ?");
mysqli_stmt_bind_param($stmt, "s", $ma);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$soSK = mysqli_fetch_assoc($result)['so'];
mysqli_stmt_close($stmt);

if ($soSK > 0) {
    header("Location: index.php");
    exit;
}

// Kiểm tra còn lịch cho ăn liên kết không
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) AS so FROM LichChoAn WHERE MaVatNuoi = ?");
mysqli_stmt_bind_param($stmt, "s", $ma);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$soLC = mysqli_fetch_assoc($result)['so'];
mysqli_stmt_close($stmt);

if ($soLC > 0) {
    header("Location: index.php");
    exit;
}

// Xóa an toàn
$stmt = mysqli_prepare($conn, "DELETE FROM VATNUOI WHERE MaVatNuoi = ?");
mysqli_stmt_bind_param($stmt, "s", $ma);
$success = mysqli_stmt_execute($stmt);

if (!$success) {
    die("Lỗi truy vấn: " . mysqli_error($conn));
}

header("Location: index.php");
mysqli_stmt_close($stmt);
?>